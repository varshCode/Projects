<?php
include('config.php');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $food_id = $_POST['food_id'];
    $food_name = $_POST['food_name'];
    $price = $_POST['price'];
    $ingredients = $_POST['ingredients'];
    $category = $_POST['category'];
    $image_path = '';

    // Validate input
    if (empty($food_id) || empty($food_name) || empty($price) || empty($ingredients) || empty($category)) {
        echo "All fields are required.";
        exit();
    }

    // Handle image upload
    if (!empty($_FILES['image']['name'])) {
        $target_dir = __DIR__ . "/uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $timestamp = time();
        $target_file = $target_dir . $timestamp . "_" . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit();
        }

        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            exit();
        }

        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit();
        }

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_path = "uploads/" . $timestamp . "_" . basename($_FILES["image"]["name"]);
        } else {
            echo "Sorry, there was an error uploading your file.";
            exit();
        }
    }

    // Check for duplicate food ID
    $checkQuery = "SELECT * FROM food_items WHERE food_id = ?";
    $check = $conn->prepare($checkQuery);
    $check->bind_param("s", $food_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "Error: Food ID already exists.";
    } else {
        // Check for duplicate food name
        $checkQuery = "SELECT * FROM food_items WHERE name = ?";
        $check = $conn->prepare($checkQuery);
        $check->bind_param("s", $food_name);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            echo "Error: Food item already exists.";
        } else {
            $sql = "INSERT INTO food_items (food_id, name, price, ingredients, category, image_path) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $food_id, $food_name, $price, $ingredients, $category, $image_path);

            if ($stmt->execute()) {
                echo "Food item added successfully.";
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }

    $check->close();
}

$conn->close();
?>
