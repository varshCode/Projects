<?php
// Include the database configuration file
include('config.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = mysqli_real_escape_string($conn, $_POST['user_id']);
    $order_date = mysqli_real_escape_string($conn, $_POST['order_date']);
    $total_amount = mysqli_real_escape_string($conn, $_POST['total_amount']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Prepare and execute the SQL query to insert the order
    $sql = "INSERT INTO orders (user_id, order_date, total_amount, status) VALUES ('$user_id', '$order_date', '$total_amount', '$status')";

    if (mysqli_query($conn, $sql)) {
        echo "Order added successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
