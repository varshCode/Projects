<?php
include('config.php');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staff_id = $_POST['staff_id'];
    $name = $_POST['name'];
    $role = $_POST['role'];

    // Check for duplicate staff ID
    $checkQuery = "SELECT * FROM staff WHERE staff_id = ?";
    $check = $conn->prepare($checkQuery);
    $check->bind_param("s", $staff_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "Error: Staff ID already exists.";
    } else {
        $sql = "INSERT INTO staff (staff_id, name, role) VALUES (?, ?, ?)";
        $check = $conn->prepare($sql);
        $check->bind_param("sss", $staff_id, $name, $role);

        if ($check->execute()) {
            echo "New staff member added successfully.";
        } else {
            echo "Error: " . $check->error;
        }
    }

    $check->close();
}

$conn->close();
?>
