<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hardcoded credentials
    $correctUsername = 'admin';
    $correctPassword = 'admin123';

    if ($username === $correctUsername && $password === $correctPassword) {
        // Set session variable
        $_SESSION['admin_logged_in'] = true;
        // Redirect to admin panel
        header('Location: admin-panel.php');
        exit;
    } else {
        // Redirect back to the login page with error
        header('Location: admin.html?error=invalid');
        exit;
    }
}
?>

