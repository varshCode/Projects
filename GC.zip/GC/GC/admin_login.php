<?php
session_start();

$username = $_POST['username'];
$password = $_POST['password'];

if ($username == 'varshadmin' && $password == 'varsh123') {
    $_SESSION['admin_logged_in'] = true;
    header('Location: admin.html');
    exit;
} else {
    echo 'Invalid username or password';
}
?>