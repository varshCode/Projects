<?php

include('config.php');

//checking the form 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data
    $food_id = mysqli_real_escape_string($conn, $_POST['food_id']);

   
    if (empty($food_id)) {
        echo "Food ID is required.";
        exit();
    }

    // delete foode
    $sql = "DELETE FROM food_items WHERE food_id = '$food_id'";

    if (mysqli_query($conn, $sql)) {
        if (mysqli_affected_rows($conn) > 0) {
            echo "Food item deleted successfully.";
        } else {
            echo "No food item found with the given ID.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


mysqli_close($conn);
?>
