<?php
// Database connection
include('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reservation_id = $_GET['id'];
$sql = "DELETE FROM reservations WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $reservation_id);
$stmt->execute();
$stmt->close();

header("Location: reservation_display.php");
exit();
?>
