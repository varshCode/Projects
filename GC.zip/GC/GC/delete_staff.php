<?php

include('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staff_id = $_POST['staff_id'];

    //check staff
    $checkQuery = "SELECT * FROM staff WHERE staff_id = ?";
    $check = $conn->prepare($checkQuery);
    $check->bind_param("s", $staff_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        // check
        $deleteQuery = "DELETE FROM staff WHERE staff_id = ?";
        $check = $conn->prepare($deleteQuery);
        $check->bind_param("s", $staff_id);

        if ($check->execute()) {
            echo "Staff member deleted successfully.";
        } else {
            echo "Error: " . $check->error;
        }

        $check->close();
    } else {
   
        echo "No staff member found with the provided ID.";
    }

}

$conn->close();
?>
