<?php
include('config.php');
session_start();

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food</title>
    <script src="https://kit.fontawesome.com/9e4a526e7f.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/cafe.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #023047;
            margin: 0;
            padding: 20px;
        }

        h1, h2 {
            text-align: center;
            color: white;
        }

        .category-section {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            margin-bottom: 40px;
        }

        .food-card {
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            width: 250px;
            height: 350px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            display: flex;
            flex-direction: column;
        }

        .food-card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }

        .food-card h3, .food-card p {
            margin: 10px;
        }

        .food-card .price {
            margin-top: 10px;
            font-size: 1.2em;
            color: #555;
        }

        .search-form {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-form input[type="text"] {
            padding: 10px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .search-form button {
            padding: 10px 20px;
            border: none;
            background-color: #023047;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navigation">
            <h3>The Gallery Cafe</h3>
            <div>
                <img src="imgs/logo.png" alt="logo">
            </div>
            <ul>
                <li><a href="index.html"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                <li><a href="admin.html"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li><a href="Staff_login.html">staff</a></li>
                <li><a href="login.html"><button type="submit" class="btn" id="logbtn">Login</button></a></li>
                <li><a href="signup.html"><button type="submit" class="btn" id="signbtn">Signup</button></a></li>
            </ul>
        </nav>
    </header>

    <div class="hero">
        <img src="imgs/front.jpeg" alt="hero image">
        <div class="overlay">
            <h2>Food</h2>
        </div>
    </div>

    <h1>Food Items</h1>

    <div class="search-form">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search by category...">
            <button type="submit">Search</button>
        </form>
    </div>

    <?php
    if (isset($_GET['search'])) {
        $search = $_GET['search'];
        echo "<h2>Results for '$search'</h2>";
        echo "<div class='category-section'>";

        $sql = "SELECT * FROM food_items WHERE category LIKE ?";
        $stmt = $conn->prepare($sql);
        $search_param = "%$search%";
        $stmt->bind_param("s", $search_param);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            echo "<div class='food-card'>";
            echo "<img src='" . $row['image_path'] . "' alt='" . $row['name'] . "'>";
            echo "<h3>" . $row['name'] . "</h3>";
            echo "<p>Ingredients: " . $row['ingredients'] . "</p>";
            echo "<p class='price'>Price: RS" . $row['price'] . "</p>";
            if (isset($_SESSION['user_id'])) {
                echo '<a href="order-display.php?food_id=' . $row["food_id"] . '" class="btn">Order</a>';
            } else {
                echo '<br>';
                echo '<p><a href="login.html" class="btn">Login to Order</a></p>';
            }
            echo "</div>";
        }

        echo "</div>";
        $stmt->close();
    } else {
        $categories = ['Sri Lankan', 'Chinese', 'Italian', 'Beverages'];

        foreach ($categories as $category) {
            echo "<h2>$category</h2>";
            echo "<div class='category-section'>";

            $sql = "SELECT * FROM food_items WHERE category = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $category);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                echo "<div class='food-card'>";
                echo "<img src='" . $row['image_path'] . "' alt='" . $row['name'] . "'>";
                echo "<h3>" . $row['name'] . "</h3>";
                echo "<p>Ingredients: " . $row['ingredients'] . "</p>";
                echo "<p class='price'>Price: RS" . $row['price'] . "</p>";
                if (isset($_SESSION['user_id'])) {
                    echo '<a href="order-display.php?food_id=' . $row["food_id"] . '" class="btn">Order</a>';
                } else {
                    echo '<br>';
                    echo '<p><a href="login.html" class="btn">Login to Order</a></p>';
                }
                echo "</div>";
            }

            echo "</div>";
            $stmt->close();
        }
    }

    $conn->close();
    ?>

    <footer>
        <p>Visit our sites</p>
        <a href="https://web.facebook.com/ParadiseRoadSriLanka" ><i class="fa-brands fa-square-facebook"></i></a>
        <a href="https://www.instagram.com/paradiseroad_srilanka?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" ><i class="fa-brands fa-square-instagram"></i></a>
        <p>&copy; 2024 Restaurant. All rights reserved.</p>
    </footer>
</body>
</html>
