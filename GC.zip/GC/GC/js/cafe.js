
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}

document.querySelectorAll('input[name="payment_method"]').forEach((elem) => {
  elem.addEventListener("change", function(event) {
      const value = event.target.value;
      if (value === "debit_card") {
          document.getElementById("debit_card_details").style.display = "block";
          document.getElementById("online_transfer_details").style.display = "none";
      } else if (value === "online_transfer") {
          document.getElementById("debit_card_details").style.display = "none";
          document.getElementById("online_transfer_details").style.display = "block";
      }
  });
});