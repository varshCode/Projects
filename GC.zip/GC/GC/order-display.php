<?php
include('config.php');
session_start();


if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$food_id = isset($_GET['food_id']) ? $_GET['food_id'] : null;
if (!$food_id) {
    echo "Invalid food item.";
    exit();
}

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fget food item details
$sql = "SELECT * FROM food_items WHERE food_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $food_id);
$stmt->execute();
$result = $stmt->get_result();
$food_item = $result->fetch_assoc();

if (!$food_item) {
    echo "Food item not found.";
    exit();
}

// Display the ord
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="css/cafe.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #023047;
            margin: 0;
            padding: 20px;
        }

        .order-card {
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            width: 300px;
            height: 400px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin: 80px auto;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .order-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }

        .order-card h3, .order-card p {
            margin: 10px;
        }

        .order-card .price {
            margin-top: 10px;
            font-size: 1.2em;
            color: #555;
        }

        .order-card .btn {
            background-color: #023047;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin: 20px;
        }

        .order-card .btn:hover {
            background-color: #005f73;
        }
    </style>
</head>
<body>
<header>
        <nav class="navigation">
            <h3>The Gallery Cafe</h3>
            <div>
                <img src="imgs/logo.png" alt="logo">
            </div>
            <ul>
                <li><a href="index.html"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                <li><a href="admin_login.html"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li><a href="Staff_login.html">staff</a></li>
                <li><a href="login.html"><button type="submit" class="btn" id="logbtn">Login</button></a></li>
                <li><a href="signup.html"><button type="submit" class="btn" id="signbtn">Signup</button></a></li>
            </ul>
        </nav>
    </header>

    <div class="order-card">
        <img src="<?php echo $food_item['image_path']; ?>" alt="<?php echo $food_item['name']; ?>">
        <h3><?php echo $food_item['name']; ?></h3>
        <p>Ingredients: <?php echo $food_item['ingredients']; ?></p>
        <p class="price">Price: RS<?php echo $food_item['price']; ?></p>
        <a href="payment.php?food_id=<?php echo $food_item['food_id']; ?>" class="btn">Confirm Order</a>

    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
