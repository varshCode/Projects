<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to place an order.";
    exit();
}

if (isset($_GET['food_id'])) {
    $food_id = $_GET['food_id'];
    $user_id = $_SESSION['user_id'];
    $order_date = date('Y-m-d H:i:s');
    $status = 'pending';

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO orders (user_id, food_id, order_date, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiss", $user_id, $food_id, $order_date, $status);

    if ($stmt->execute()) {
        echo "Order placed successfully!";
    } else {
        echo "Error placing order: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "No food item selected.";
}
?>
