<?php

include('config.php');
$order_id = $_GET['order_id'];


// Delete order 
$sql = "DELETE FROM orders WHERE order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $order_id);
$stmt->execute();

header("Location: staff_dashbord.php");
?>
