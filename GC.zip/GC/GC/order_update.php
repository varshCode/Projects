<?php
include('config.php');

$order_id = $_GET['order_id'];


$sql = "SELECT * FROM orders WHERE order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $price = $_POST['price'];
    $payment_method = $_POST['payment_method'];

    // Update order 
    $update_sql = "UPDATE orders SET price = ?, payment_method = ? WHERE order_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param('dsi', $price, $payment_method, $order_id);
    $update_stmt->execute();

    header("Location: staff_dashbord.php");
}

?>

<form method="post">
    <label>Price:</label>
    <input type="text" name="price" value="<?php echo htmlspecialchars($order['price']); ?>" required>
    <label>Payment Method:</label>
    <select name="payment_method" required>
        <option value="debit_card" <?php echo $order['payment_method'] == 'debit_card' ? 'selected' : ''; ?>>Debit Card</option>
        <option value="online_transfer" <?php echo $order['payment_method'] == 'online_transfer' ? 'selected' : ''; ?>>Online Transfer</option>
    </select>
    <button type="submit">Update</button>
</form>
