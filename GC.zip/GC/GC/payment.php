<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$food_id = isset($_GET['food_id']) ? $_GET['food_id'] : null;
if (!$food_id) {
    echo "Invalid food item.";
    exit();
}

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch food item details
$sql = "SELECT * FROM food_items WHERE food_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $food_id);
$stmt->execute();
$result = $stmt->get_result();
$food_item = $result->fetch_assoc();

if (!$food_item) {
    echo "Food item not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="css/cafe.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #023047;
            margin: 0;
            padding: 20px;
        }

        .payment-form {
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            max-width: 500px;
            margin: 20px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .payment-form h2 {
            margin-top: 0;
        }

        .payment-form input[type="text"], .payment-form input[type="number"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .payment-form .btn {
            background-color: #023047;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            display: inline-block;
        }

        .payment-form .btn:hover {
            background-color: #005f73;
        }

        .payment-method {
            margin: 20px 0;
        }

        .payment-method input[type="radio"] {
            margin-right: 10px;
        }
    </style>
</head>
<body>
<header>
        <nav class="navigation">
            <h3>The Gallery Cafe</h3>
            <div>
                <img src="imgs/logo.png" alt="logo">
            </div>
            <ul>
                <li><a href="index.html"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                <li><a href="admin_login.html"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li><a href="Staff_login.html">staff</a></li>
                <li><a href="login.html"><button type="submit" class="btn" id="logbtn">Login</button></a></li>
                <li><a href="signup.html"><button type="submit" class="btn" id="signbtn">Signup</button></a></li>
            </ul>
        </nav>
    </header>

    <div class="payment-form">
        <h2>Payment Details</h2>
        <form method="POST" action="process_payment.php">
            <input type="hidden" name="food_id" value="<?php echo $food_id; ?>">
            <input type="hidden" name="price" value="<?php echo $food_item['price']; ?>">

            <div class="payment-method">
                <input type="radio" id="debit_card" name="payment_method" value="debit_card" required>
                <label for="debit_card">Debit Card</label><br>
                <input type="radio" id="online_transfer" name="payment_method" value="online_transfer" required>
                <label for="online_transfer">Online Transfer</label>
            </div>

            <div id="debit_card_details" style="display:none;">
                <input type="text" name="card_number" placeholder="Card Number">
                <input type="text" name="card_expiry" placeholder="Expiry Date (MM/YY)">
                <input type="text" name="card_cvc" placeholder="CVC">
            </div>

            <div id="online_transfer_details" style="display:none;">
                <input type="text" name="bank_name" placeholder="Bank Name">
                <input type="text" name="account_number" placeholder="Account Number">
            </div>

            <button type="submit" class="btn">Pay</button>
        </form>
    </div>

    <script>
        document.querySelectorAll('input[name="payment_method"]').forEach((elem) => {
            elem.addEventListener("change", function(event) {
                const value = event.target.value;
                if (value === "debit_card") {
                    document.getElementById("debit_card_details").style.display = "block";
                    document.getElementById("online_transfer_details").style.display = "none";
                } else if (value === "online_transfer") {
                    document.getElementById("debit_card_details").style.display = "none";
                    document.getElementById("online_transfer_details").style.display = "block";
                }
            });
        });
    </script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
