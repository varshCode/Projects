<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$food_id = isset($_POST['food_id']) ? $_POST['food_id'] : null;
$price = isset($_POST['price']) ? $_POST['price'] : null;
$payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : null;

if (!$food_id || !$price || !$payment_method) {
    echo "Invalid request.";
    exit();
}

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert orderetails 
$sql = "INSERT INTO orders (user_id, food_id, price, payment_method) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiss", $user_id, $food_id, $price, $payment_method);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Order placed successfully.";
} else {
    echo "Failed to place the order.";
}

$stmt->close();
$conn->close();
?>
