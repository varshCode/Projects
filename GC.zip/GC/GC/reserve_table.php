<?php

include('config.php'); 

//gret data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$reservation_date = $_POST['reservation_date'];
$reservation_time = $_POST['reservation_time'];
$num_people = $_POST['num_people'];
$special_request = $_POST['special_request'];

// Check for reservations
$sql_check = $conn->prepare("SELECT COUNT(*) FROM reservations WHERE reservation_date = ? AND reservation_time = ?");
$sql_check->bind_param('ss', $reservation_date, $reservation_time);
$sql_check->execute();
$sql_check->bind_result($count);
$sql_check->fetch();
$sql_check->close();

if ($count > 0) {
    // 
    echo "Sorry, the selected time slot is already booked. Please choose a different time.";
} else {
    
    $sql = $conn->prepare("INSERT INTO reservations (name, email, phone, reservation_date, reservation_time, num_people, special_request) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $sql->bind_param('sssssss', $name, $email, $phone, $reservation_date, $reservation_time, $num_people, $special_request);

    //execute
    if ($sql->execute()) {
     
        header("Location: staff_dashbord.php");
        exit();
    } else {
        echo "Error: " . $sql->error;
    }

    $sql->close();
}

$conn->close();
?>
