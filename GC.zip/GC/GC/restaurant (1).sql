-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2024 at 10:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `user_id`, `name`, `email`, `message`, `created_at`) VALUES
(4, 16, 'Srishanker Heshavrashaan', 'heshcage29@gmail.com', 'can\\\'t place order\\r\\n', '2024-08-09 16:07:46');

-- --------------------------------------------------------

--
-- Table structure for table `food_items`
--

CREATE TABLE `food_items` (
  `food_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `ingredients` text NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food_items`
--

INSERT INTO `food_items` (`food_id`, `name`, `price`, `image_path`, `ingredients`, `category`) VALUES
(2, 'kiri bath', 350.00, 'uploads/1723090712_srilankan2.jpeg', 'kerijkfjskdf', 'Sri Lankan'),
(3, 'lasange', 700.00, 'uploads/1723092868_italian1 (1).jpeg', 'ejkfkj', 'Italian'),
(5, 'blue mocktail', 450.00, 'uploads/1723160895_bv2.jpeg', 'blue vine , lemon ', 'Beverages'),
(6, 'Rooti', 450.00, 'uploads/1723160712_srilankan1.jpeg', 'cocnut,salt,', 'Sri Lankan'),
(7, 'pork belly', 450.00, 'uploads/1723160951_chinese5.jpeg', 'pork belly , lemon , soya sauce', 'Chinese'),
(8, 'levery', 200.00, 'uploads/1723175593_srilankan3.jpeg', 'cocconut milk, wheat flour, suger syrup', 'Sri Lankan'),
(9, 'silico Noodles', 750.00, 'uploads/1723192533_chinese1.jpeg', 'wrap sheet, chicken, potato', 'Chinese'),
(10, 'money bag', 1000.00, 'uploads/1723192609_chinese2.jpeg', 'wrap sheet, chicken, olivr oil, potato ', 'Chinese');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `food_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `payment_method` enum('debit_card','online_transfer') NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `food_id`, `price`, `payment_method`, `order_date`) VALUES
(5, 11, 2, 350.00, 'debit_card', '2024-08-08 10:15:12'),
(6, 11, 2, 350.00, 'online_transfer', '2024-08-08 10:30:01'),
(8, 15, 6, 450.00, 'debit_card', '2024-08-09 14:13:46'),
(9, 15, 6, 450.00, 'debit_card', '2024-08-09 14:21:50'),
(10, 15, 2, 350.00, 'debit_card', '2024-08-09 15:40:09');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `reservation_date` date NOT NULL,
  `reservation_time` time NOT NULL,
  `num_people` int(11) NOT NULL,
  `special_request` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `name`, `email`, `phone`, `reservation_date`, `reservation_time`, `num_people`, `special_request`, `user_id`) VALUES
(31, 'Srishanker Heshavrashaan', 'heshcage29@gmail.com', '0789906745', '2024-08-09', '21:40:00', 5, 'need beer as complement', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `staff_id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `staff_id`, `name`, `role`, `created_at`, `updated_at`) VALUES
(25, '1', 'varshaan', 'developer', '2024-08-08 10:41:28', '2024-08-10 07:33:09'),
(26, '2', 'jack', 'master chef', '2024-08-09 03:50:40', '2024-08-09 03:50:40'),
(27, '3', 'jhon', 'Cleaner', '2024-08-09 03:50:57', '2024-08-09 03:50:57'),
(28, '4', 'Mick', 'accountent', '2024-08-09 03:51:15', '2024-08-09 03:51:15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `phone`, `email`, `password`, `role`) VALUES
(14, 'Brocode', '0740464926', 'heshavarshan@gmail.com', '$2y$10$ZAihQhw9rzmbnQnXdLZyr.mqHnRWwDIWL8eZS9M2O3kl0D2IlhJim', 'customer'),
(15, 'yty', '909', 'jk@gamil.com', '$2y$10$qGhEWrmyf2adOLi0VUIj5eamFZQuoOJp8fR2zR8BSZa5SVLMbOM1y', 'customer'),
(16, 'jacksparrow', '0789906745', 'jack@gmail.com', '$2y$10$0y5h5VigLRS1vvxAbKyfjufRQroIwkRTBmMVvlaQWf09XmDOiyXQm', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `food_items`
--
ALTER TABLE `food_items`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `food_items`
--
ALTER TABLE `food_items`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD CONSTRAINT `contact_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
