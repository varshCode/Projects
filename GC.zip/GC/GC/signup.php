<?php
include('config.php'); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    
    $check_sql = "SELECT * FROM users WHERE username = '$username' OR 
    email = '$email'";

    $result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($result) > 0) {



        echo "Username or email is already taken. Please choose a different one.";
    } else {
        $sql = "INSERT INTO users (username, phone, email, password) VALUES ('$username', '$phone', '$email', '$password')";
        
        if (mysqli_query($conn, $sql)) {
           
            header("Location: login.html");
            exit();
            
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}
?>

