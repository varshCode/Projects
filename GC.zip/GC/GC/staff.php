<?php
// Include the database configuration file
include('config.php');

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch staff data
$sql = "SELECT * FROM staff";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Staff</title>
    <script src="https://kit.fontawesome.com/9e4a526e7f.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/cafe.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #023047;
            margin: 0;
            padding: 20px;
        }

        h1, h2 {
            text-align: center;
            color: white;
        }

        .staff-section {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            margin-bottom: 40px;
        }

        .staff-card {
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            width: 250px;
            height: 200px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .staff-card h3, .staff-card p {
            margin: 10px;
        }

        .staff-card .role {
            margin-top: 10px;
            font-size: 1.2em;
            color: #555;
        }
        .staff-card i{
            font-size: 1.5em;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navigation">
            <h3>The Gallery Cafe</h3>
            <div>
                <img src="imgs/logo.png" alt="logo">
            </div>
            <ul>
                <li><a href="index.html"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                <li><a href="admin.html"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li><a href="login.html"><button type="submit" class="btn" id="logbtn">Login</button></a></li>
                <li><a href="signup.html"><button type="submit" class="btn" id="signbtn">Signup</button></a></li>
            </ul>
        </nav>
    </header>

    <div class="hero">
        <img src="imgs/tree.png" alt="hero image">
        <div class="overlay">
            <h2>Staff</h2>
        </div>
    </div>

    <h1>Our Staff</h1>

    <div class="staff-section">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='staff-card'>";
                echo "<i class='fa-solid fa-user-tie'></i>";
                echo "<h3>" . $row["name"] . "</h3>";
                echo "<p class='role'>Role: " . $row["role"] . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No staff members found</p>";
        }
        ?>
    </div>

    <footer>
        <p>Visit our sites</p>
        <a href="https://web.facebook.com/ParadiseRoadSriLanka" ><i class="fa-brands fa-square-facebook"></i></a>
        <a href="https://www.instagram.com/paradiseroad_srilanka?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" ><i class="fa-brands fa-square-instagram"></i></a>
        <p>&copy; 2024 Restaurant. All rights reserved.</p>
    </footer>
</body>
</html>
<?php
$conn->close();
?>
