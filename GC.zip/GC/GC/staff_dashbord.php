<?php
// Include the configuration file
include('config.php'); // Ensure the file name and path are correct

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch orders
$sql = "SELECT * FROM orders";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://kit.fontawesome.com/9e4a526e7f.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/cafe.css">
<body>
<header>
        <nav class="navigation">
            <h3>The Gallery Cafe</h3>
            <div>
                <img src="imgs/logo.png" alt="logo">
            </div>
            <ul>
                <li><a href="index.html"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                <li><a href="admin_login.html"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li><a href="Staff_login.html">staff</a></li>
                <li><a href="login.html"><button type="submit" class="btn" id="logbtn">Login</button></a></li>
                <li><a href="signup.html"><button type="submit" class="btn" id="signbtn">Signup</button></a></li>
            </ul>
        </nav>
    </header>

    <div class="hero">
        <img src="imgs/tree.png" alt="hero image">
        <div class="overlay">
            <h2>Staff_dashboard</h2>
        </div>
    </div>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Orders Dashboard</h1>
    <table>
     
            <?php
           if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Order ID</th><th>User ID</th><th>Food ID</th><th>Price</th><th>Payment Method</th><th>Order Date</th><th>Actions</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['order_id'] . "</td>";
                echo "<td>" . $row['user_id'] . "</td>";
                echo "<td>" . $row['food_id'] . "</td>";
                echo "<td>" . $row['price'] . "</td>";
                echo "<td>" . $row['payment_method'] . "</td>";
                echo "<td>" . $row['order_date'] . "</td>";
                echo "<td>
                        <a href='order_update.php?order_id=" . $row['order_id'] . "'>Update</a> | 
                        <a href='order_delete.php?order_id=" . $row['order_id'] . "' onclick='return confirm(\"Are you sure you want to delete this order?\");'>Delete</a>
                      </td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No orders found.";
        }
        echo"<br>";
        $conn->close();
        ?>



<?php
include('config.php');



$sql = "SELECT * FROM reservations ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

?>

<?php


include('config.php');

// Fetch all reservations
$sql = "SELECT * FROM reservations";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Reservations</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <h1>All Reservations</h1>
    <?php
    if ($result->num_rows > 0) {
        ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Number of People</th>
                    <th>Special Request</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                    <td><?php echo htmlspecialchars($row['reservation_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reservation_time']); ?></td>
                    <td><?php echo htmlspecialchars($row['num_people']); ?></td>
                    <td><?php echo htmlspecialchars($row['special_request']); ?></td>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <footer>
        <p>Visit our sites</p>
        <a href="https://web.facebook.com/ParadiseRoadSriLanka" ><i class="fa-brands fa-square-facebook"></i></a>
        <a href="https://www.instagram.com/paradiseroad_srilanka?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" ><i class="fa-brands fa-square-instagram"></i></a>
        <p>&copy; 2024 Restaurant. All rights reserved.</p>
    </footer>
        <?php
    } else {
        echo "<p>No reservations found.</p>";
    }

    $conn->close();
    ?>
</body>
</html>
