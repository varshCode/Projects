<?php

include('config.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get  data
$staff_id = $_POST['staff_id'];
$name = $_POST['name'];

$sql = $conn->prepare("SELECT * FROM staff WHERE staff_id = ? AND name = ?");
$sql->bind_param('ss', $staff_id, $name);


$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    
    header("Location: staff_dashbord.php");
    exit();
} else {

    echo "<p>Invalid Staff ID or Name</p>";
}


$conn->close();
?>
