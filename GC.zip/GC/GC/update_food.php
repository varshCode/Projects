<?php
include('config.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $food_id = mysqli_real_escape_string($conn, $_POST['food_id']);
    $new_name = mysqli_real_escape_string($conn, $_POST['new_name']);
    $new_price = mysqli_real_escape_string($conn, $_POST['new_price']);
    $new_ingredients = mysqli_real_escape_string($conn, $_POST['new_ingredients']);
    $new_category = mysqli_real_escape_string($conn, $_POST['new_category']);
    $image_path = '';

    if (empty($food_id)) {
        echo "Food ID is required.";
        exit();
    }

    $check_sql = "SELECT * FROM food_items WHERE food_id = '$food_id'";
    $result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($result) == 0) {
        echo "Error: No food item found with the given ID.";
        exit();
    }

    if (!empty($_FILES['image']['name'])) {
        $target_dir = __DIR__ . "/uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $timestamp = time();
        $target_file = $target_dir . $timestamp . "_" . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit();
        }

        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            exit();
        }

        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit();
        }

    }
    $updates = array();
    if (!empty($new_name)) {
        $updates[] = "name = '$new_name'";
    }
    if (!empty($new_price)) {
        $updates[] = "price = '$new_price'";
    }
    if (!empty($new_ingredients)) {
        $updates[] = "ingredients = '$new_ingredients'";
    }
    if (!empty($new_category)) {
        $updates[] = "category = '$new_category'";
    }
    if (!empty($image_path)) {
        $updates[] = "image_path = '$image_path'";
    }

    if (empty($updates)) {
        echo "No updates to apply.";
        exit();
    }

    $updates_str = implode(", ", $updates);
    $sql = "UPDATE food_items SET $updates_str WHERE food_id = '$food_id'";

    if (mysqli_query($conn, $sql)) {
        echo "Food item updated successfully.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
