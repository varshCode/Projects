<?php

include('config.php');

// Check if the form is submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
    $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);

    // Prepare and execute the SQL query to update the order status
    $sql = "UPDATE orders SET status = '$new_status' WHERE id = '$order_id'";

    if (mysqli_query($conn, $sql)) {
        if (mysqli_affected_rows($conn) > 0) {
            echo "Order updated successfully.";
        } else {
            echo "No order found with the given ID.";
        }
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
