<?php

include('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staff_id = $_POST['staff_id'];
    $new_name = $_POST['new_name'];
    $new_role = $_POST['new_role'];

    // Check if staff member exists
    $checkQuery = "SELECT * FROM staff WHERE staff_id = ?";
    $check = $conn->prepare($checkQuery);
    $check->bind_param("s", $staff_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        // check staff member
        $updateQuery = "UPDATE staff SET name = COALESCE(NULLIF(?, ''), name), role = COALESCE(NULLIF(?, ''), role) WHERE staff_id = ?";
        $check = $conn->prepare($updateQuery);
        $check->bind_param("sss", $new_name, $new_role, $staff_id);

        if ($check->execute()) {
            echo "Staff member updated successfully.";
        } else {
            echo "Error: " . $check->error;
        }
    } else {
        echo "No staff member found with the provided ID.";
    }

    $check->close();
}

$conn->close();
?>
