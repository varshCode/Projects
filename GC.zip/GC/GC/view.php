<?php
session_start();
include('config.php'); // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch messages for the logged-in user
$sql = "SELECT name, email, message, created_at FROM contact_messages WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sent Messages</title>
    <link rel="stylesheet" href="css/cafe.css">
</head>
<body>
    <header>
        <nav class="navigation">
            <h3>The Gallery Cafe</h3>
            <div>
                <img src="imgs/logo.png" alt="logo">
            </div>
            <ul>
                <li><a href="index.html"><i class="fa-solid fa-house"></i> Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="contact.html"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                <li><a href="admin.html"><i class="fa-solid fa-user-tie"></i> Admin</a></li>
                <li><a href="Staff_login.html">staff</a></li>
                <li><a href="login.html"><button type="submit" class="btn" id="logbtn">Login</button></a></li>
                <li><a href="signup.html"><button type="submit" class="btn" id="signbtn">Signup</button></a></li>
            </ul>
        </nav>
    </header>
    
    <div class="hero">
        <img src="imgs/table.jpeg" alt="hero image">
        <div class="overlay">
            <h2>Sent Messages</h2>
        </div>
    </div>

    <main>
        <div class="message-container">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='message-card'>";
                    echo "<p><strong>Name:</strong> " . htmlspecialchars($row['name']) . "</p>";
                    echo "<p><strong>Email:</strong> " . htmlspecialchars($row['email']) . "</p>";
                    echo "<p><strong>Message:</strong> " . htmlspecialchars($row['message']) . "</p>";
                    echo "<p><strong>Sent At:</strong> " . $row['created_at'] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No messages found.</p>";
            }
            ?>
        </div>
    </main>

    <footer>
        <p>Visit our sites</p>
        <a href="https://web.facebook.com/ParadiseRoadSriLanka" ><i class="fa-brands fa-square-facebook"></i></a>
        <a href="https://www.instagram.com/paradiseroad_srilanka?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" ><i class="fa-brands fa-square-instagram"></i></a>
        <p>&copy; 2024 Restaurant. All rights reserved.</p>
    </footer>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
